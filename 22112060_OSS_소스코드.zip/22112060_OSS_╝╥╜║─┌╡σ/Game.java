import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private final String displayName;
    private final String bannerImage;
    private final String buttonImage;
    private final File folder;
    private final List<Post> posts;

    public Game(String displayName, String bannerImage, String buttonImage) {
        this.displayName = displayName;
        this.bannerImage = bannerImage;
        this.buttonImage = buttonImage;
        this.posts = new ArrayList<>();

        String safeName = displayName.replaceAll("\\s+", "_");
        this.folder     = new File("data" + File.separator + safeName);

        if (!folder.exists()) {
            folder.mkdirs();
        }
        loadPosts();
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBannerImage() {
        return bannerImage;
    }

    public String getButtonImage() {
        return buttonImage;
    }

    public List<Post> getPosts() {
        return posts;
    }

    private void loadPosts() {
        posts.clear();
        File[] files = folder.listFiles((dir, fname) -> fname.toLowerCase().endsWith(".txt"));
        if (files == null) return;

        for (File f : files) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String author  = reader.readLine();
                String title   = reader.readLine();
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                String content = sb.toString().trim();
                String filename = f.getName();
                Post p = new Post(title, content, author, filename);
                posts.add(p);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void addPost(Post p) {
        String safeTitle = p.getTitle().replaceAll("[\\\\/:*?\"<>|]", "_");
        String filename  = System.currentTimeMillis() + "_" + safeTitle + ".txt";
        File outFile     = new File(folder, filename);

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(outFile), StandardCharsets.UTF_8))) {
            writer.write(p.getAuthor());
            writer.newLine();
            writer.write(p.getTitle());
            writer.newLine();
            writer.write(p.getContent());
            writer.newLine();
            writer.flush();

            p.setFilename(filename);
            posts.add(p);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removePost(Post p) {
        posts.remove(p);
        String fn = p.getFilename();
        if (fn != null) {
            File f = new File(folder, fn);
            if (f.exists()) {
                f.delete();
            }
        }
    }
}
