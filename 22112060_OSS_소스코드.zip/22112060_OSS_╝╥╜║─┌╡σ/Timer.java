import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Timer extends JFrame {
    private JLabel timeLabel;
    private JSpinner hourSpinner, minuteSpinner, secondSpinner;
    private JButton startBtn, stopBtn, resetBtn;
    private JCheckBox pipCheck;

    private javax.swing.Timer swingTimer;

    private int remainSeconds = 0;

    public Timer() {
        setTitle("타이머");
        setSize(300, 150);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));
        inputPanel.setBackground(Color.WHITE);

        hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
        minuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
        secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));

        inputPanel.add(hourSpinner);
        inputPanel.add(new JLabel("시"));
        inputPanel.add(minuteSpinner);
        inputPanel.add(new JLabel("분"));
        inputPanel.add(secondSpinner);
        inputPanel.add(new JLabel("초"));

        add(inputPanel, BorderLayout.NORTH);

        timeLabel = new JLabel(formatTime(0), SwingConstants.CENTER);
        timeLabel.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        timeLabel.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        add(timeLabel, BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));
        southPanel.setBackground(Color.WHITE);

        startBtn = new JButton("시작");
        stopBtn = new JButton("정지");
        resetBtn = new JButton("리셋");
        pipCheck = new JCheckBox("PiP");

        southPanel.add(startBtn);
        southPanel.add(stopBtn);
        southPanel.add(resetBtn);
        southPanel.add(pipCheck);

        add(southPanel, BorderLayout.SOUTH);

        swingTimer = new javax.swing.Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (remainSeconds > 0) {
                    remainSeconds--;
                    timeLabel.setText(formatTime(remainSeconds));
                } else {
                    swingTimer.stop();
                    JOptionPane.showMessageDialog(Timer.this, "타이머가 종료되었습니다.");
                }
            }
        });

        startBtn.addActionListener(e -> {
            int hrs = (int) hourSpinner.getValue();
            int mins = (int) minuteSpinner.getValue();
            int secs = (int) secondSpinner.getValue();
            remainSeconds = hrs * 3600 + mins * 60 + secs;
            timeLabel.setText(formatTime(remainSeconds));
            swingTimer.start();
        });

        stopBtn.addActionListener(e -> swingTimer.stop());

        resetBtn.addActionListener(e -> {
            swingTimer.stop();
            remainSeconds = 0;
            timeLabel.setText(formatTime(remainSeconds));
        });

        pipCheck.addActionListener(e -> setAlwaysOnTop(pipCheck.isSelected()));
    }

    private String formatTime(int totalSec) {
        int hours = totalSec / 3600;
        int minutes = (totalSec % 3600) / 60;
        int seconds = totalSec % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
