
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TFGCommunity extends JFrame {
    private JLabel bannerImage;
    private JButton loginBtn;
    private JButton userMgmtBtn;
    private String currentUserNickname = null;

    private final List<Game> sidebarGames = new ArrayList<>();
    private final List<Game> allGames = new ArrayList<>();
    private Game currentGame;

    private JPanel postListPanel;
    private JButton newPostBtn;

    private final File askFolder = new File("data/ask");
    private final File userFile = new File("data/user.txt");

    public TFGCommunity() {
        setTitle("TfG 커뮤니티");
        setSize(1024, 768);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        allGames.add(new Game("리그 오브 레전드","src/img/lol_banner.png","src/img/lol_btn.png"));
        allGames.add(new Game("발로란트","src/img/valorant_banner.png","src/img/valorant_btn.png"));
        allGames.add(new Game("오버워치","src/img/overwatch_banner.png","src/img/overwatch_btn.png"));
        allGames.add(new Game("전략적 팀 전투","src/img/tft_banner.png","src/img/tft_btn.png"));
        allGames.add(new Game("디아블로","src/img/diablo_banner.png", null));

        for (int i = 0; i < 4; i++) {
            Game g = allGames.get(i);
            if (g.getBannerImage() != null) {
                sidebarGames.add(g);
            }
        }
        currentGame = sidebarGames.get(0);

        if (!askFolder.exists()) {
            askFolder.mkdirs();
        }
        try {
            if (!userFile.exists()) {
                userFile.createNewFile();
            }
        } catch (IOException ignored) { }

        JPanel westWrapper = new JPanel(new BorderLayout());
        westWrapper.add(buildSidebar(), BorderLayout.WEST);

        JPanel separator = new JPanel();
        separator.setPreferredSize(new Dimension(2, getHeight()));
        separator.setBackground(Color.YELLOW);
        westWrapper.add(separator, BorderLayout.CENTER);

        add(westWrapper, BorderLayout.WEST);

        add(buildMainPanel(), BorderLayout.CENTER);
    }

    private JPanel buildSidebar() {
        JPanel side = new JPanel();
        side.setPreferredSize(new Dimension(300, getHeight()));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBackground(new Color(1, 2, 1));

        Image logoImg = new ImageIcon("src/img/logo.png")
                .getImage()
                .getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(logoImg));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        side.add(logoLabel);

        loginBtn = new JButton("로그인");
        loginBtn.setMaximumSize(new Dimension(200, 40));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setBackground(new Color(255, 215, 0));
        loginBtn.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        loginBtn.addActionListener(e -> {
            Login dlg = new Login(this);
            User user = dlg.showDialogue();
            if (user != null) {
                updateLoginState(user.getNickname());
            }
        });
        side.add(Box.createVerticalStrut(10));
        side.add(loginBtn);

        JButton requestBtn = new JButton("요청");
        requestBtn.setMaximumSize(new Dimension(200, 40));
        requestBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        requestBtn.setBackground(new Color(100, 100, 120));
        requestBtn.setForeground(Color.WHITE);
        requestBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        requestBtn.addActionListener(e -> {
            if (currentUserNickname == null) {
                JOptionPane.showMessageDialog(this, "로그인 후 이용 가능합니다.");
                return;
            }
            if ("admin".equals(currentUserNickname)) {
                showAskListForAdmin();
            } else {
                openNewAskDialogue();
            }
        });
        side.add(Box.createVerticalStrut(10));
        side.add(requestBtn);

        userMgmtBtn = new JButton("유저 관리");
        userMgmtBtn.setMaximumSize(new Dimension(200, 40));
        userMgmtBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        userMgmtBtn.setBackground(new Color(150, 50, 50));
        userMgmtBtn.setForeground(Color.WHITE);
        userMgmtBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        userMgmtBtn.setVisible(false);
        userMgmtBtn.addActionListener(e -> showUserManagementDialogue());
        side.add(Box.createVerticalStrut(10));
        side.add(userMgmtBtn);

        side.add(Box.createVerticalGlue());

        JPanel toolPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        toolPanel.setMaximumSize(new Dimension(280, 40));
        toolPanel.setOpaque(false);

        JButton memoBtn = new JButton("메모장");
        memoBtn.setBackground(new Color(100, 100, 120));
        memoBtn.setForeground(Color.WHITE);
        memoBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        memoBtn.addActionListener(e2 -> new Memo().setVisible(true));
        toolPanel.add(memoBtn);

        JButton timerBtn = new JButton("타이머");
        timerBtn.setBackground(new Color(100, 100, 120));
        timerBtn.setForeground(Color.WHITE);
        timerBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        timerBtn.addActionListener(e2 -> new Timer().setVisible(true));
        toolPanel.add(timerBtn);

        side.add(toolPanel);
        side.add(Box.createVerticalStrut(10));

        JPanel gameButtons = new JPanel();
        gameButtons.setLayout(new BoxLayout(gameButtons, BoxLayout.Y_AXIS));
        gameButtons.setOpaque(false);

        for (Game g : sidebarGames) {
            Image btnImg = new ImageIcon(g.getButtonImage())
                    .getImage()
                    .getScaledInstance(280, 40, Image.SCALE_SMOOTH);
            JButton btn = new JButton(new ImageIcon(btnImg));
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(280, 40));
            btn.setBorderPainted(false);
            btn.setContentAreaFilled(false);
            btn.addActionListener(evt -> {
                currentGame = g;
                bannerImage.setIcon(new ImageIcon(g.getBannerImage()));
                refreshPosts();
            });
            gameButtons.add(btn);
            gameButtons.add(Box.createVerticalStrut(5));
        }
        side.add(gameButtons);

        JButton addGameBtn = new JButton("다른 게임 선택");
        addGameBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        addGameBtn.setMaximumSize(new Dimension(280, 40));
        addGameBtn.setBackground(new Color(100, 100, 120));
        addGameBtn.setForeground(Color.WHITE);
        addGameBtn.setFocusPainted(false);
        addGameBtn.addActionListener(evt -> {
            List<String> options = new ArrayList<>();
            for (Game g : allGames) {
                if (!sidebarGames.contains(g)) {
                    options.add(g.getDisplayName());
                }
            }
            String[] arr = options.toArray(new String[0]);
            String choice = (String) JOptionPane.showInputDialog(
                    this,
                    "추가할 게임을 선택하세요:",
                    "게임 선택",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    arr,
                    arr.length > 0 ? arr[0] : null
            );
            if (choice != null) {
                Game selected = null;
                for (Game g : allGames) {
                    if (g.getDisplayName().equals(choice)) {
                        selected = g;
                        break;
                    }
                }
                if (selected != null) {
                    currentGame = selected;
                    if (selected.getBannerImage() != null) {
                        bannerImage.setIcon(new ImageIcon(selected.getBannerImage()));
                        bannerImage.setText("");
                    } else {
                        bannerImage.setIcon(null);
                        bannerImage.setText("[" + choice + "] 배너가 없습니다.");
                        bannerImage.setForeground(Color.WHITE);
                        bannerImage.setHorizontalAlignment(SwingConstants.CENTER);
                    }
                    refreshPosts();
                }
            }
        });
        side.add(Box.createVerticalStrut(10));
        side.add(addGameBtn);
        side.add(Box.createVerticalStrut(10));

        return side;
    }

    private JPanel buildMainPanel() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(new Color(40, 40, 60));

        bannerImage = new JLabel(new ImageIcon(sidebarGames.get(0).getBannerImage()));
        bannerImage.setHorizontalAlignment(SwingConstants.CENTER);
        bannerImage.setPreferredSize(new Dimension(700, 200));
        main.add(bannerImage, BorderLayout.NORTH);

        postListPanel = new JPanel();
        postListPanel.setLayout(new BoxLayout(postListPanel, BoxLayout.Y_AXIS));
        postListPanel.setBackground(new Color(60, 60, 80));
        JScrollPane scroll = new JScrollPane(postListPanel);
        scroll.setBorder(null);
        main.add(scroll, BorderLayout.CENTER);

        newPostBtn = new JButton("새 게시글 작성");
        newPostBtn.setBackground(new Color(80, 80, 120));
        newPostBtn.setForeground(Color.WHITE);
        newPostBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        newPostBtn.addActionListener(e -> {
            if (currentUserNickname == null) {
                JOptionPane.showMessageDialog(this, "로그인 후 이용 가능합니다.");
                return;
            }
            openNewPostDialogue();
        });
        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(40, 40, 60));
        bottom.add(newPostBtn);
        main.add(bottom, BorderLayout.SOUTH);

        refreshPosts();
        return main;
    }

    private void refreshPosts() {
        postListPanel.removeAll();
        List<Post> list = currentGame.getPosts();
        if (!list.isEmpty()) {
            for (Post p : list) {
                JPanel item = new JPanel(new BorderLayout());
                item.setMaximumSize(new Dimension(680, 60));
                item.setBackground(new Color(70, 70, 90));

                JButton viewBtn = new JButton(p.getTitle());
                viewBtn.setForeground(Color.WHITE);
                viewBtn.setBackground(new Color(90, 90, 110));
                viewBtn.setBorderPainted(false);
                viewBtn.setContentAreaFilled(false);
                viewBtn.setHorizontalAlignment(SwingConstants.LEFT);
                viewBtn.setPreferredSize(new Dimension(0, 40));
                viewBtn.addActionListener(evt -> showPostDetail(p));
                item.add(viewBtn, BorderLayout.CENTER);

                JPanel eastPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 10));
                eastPanel.setOpaque(false);

                JLabel authorLabel = new JLabel("작성자 : " + p.getAuthor());
                authorLabel.setForeground(Color.LIGHT_GRAY);

                JButton deleteBtn = new JButton("삭제");
                deleteBtn.setForeground(Color.WHITE);
                deleteBtn.setBackground(new Color(150, 50, 50));
                deleteBtn.setFocusPainted(false);
                deleteBtn.setPreferredSize(new Dimension(60, 40));
                deleteBtn.addActionListener(evt -> {
                    if (currentUserNickname == null) {
                        JOptionPane.showMessageDialog(this, "로그인 후 이용 가능합니다.");
                    } else if ("admin".equals(currentUserNickname) || currentUserNickname.equals(p.getAuthor())) {
                        currentGame.removePost(p);
                        refreshPosts();
                    } else {
                        JOptionPane.showMessageDialog(this, "본인 글만 삭제할 수 있습니다.");
                    }
                });

                eastPanel.add(authorLabel);
                eastPanel.add(deleteBtn);
                item.add(eastPanel, BorderLayout.EAST);

                postListPanel.add(item);
                postListPanel.add(Box.createVerticalStrut(5));
            }
        } else {
            JLabel empty = new JLabel("게시글이 없습니다.");
            empty.setForeground(Color.WHITE);
            postListPanel.add(empty);
        }
        postListPanel.revalidate();
        postListPanel.repaint();
    }

    private void showPostDetail(Post p) {
        JTextArea area = new JTextArea(p.getContent());
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBackground(Color.WHITE);
        area.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(
                this,
                sp,
                p.getTitle() + " - " + p.getAuthor(),
                JOptionPane.PLAIN_MESSAGE
        );
    }

    private void openNewPostDialogue() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 5);
        g.anchor = GridBagConstraints.WEST;

        JTextField titleField = new JTextField(20);
        JTextArea contentArea = new JTextArea(5, 20);
        JButton postBtn = new JButton("등록");
        postBtn.setBackground(new Color(255, 215, 0));

        g.gridx = 0; g.gridy = 0; panel.add(new JLabel("제목"), g);
        g.gridx = 1; panel.add(titleField, g);
        g.gridx = 0; g.gridy = 1; panel.add(new JLabel("내용"), g);
        g.gridx = 1; panel.add(new JScrollPane(contentArea), g);
        g.gridx = 1; g.gridy = 2; panel.add(postBtn, g);

        JDialog dialog = new JDialog(this, "새 게시글 작성 (" + currentGame.getDisplayName() + ")", true);
        dialog.getContentPane().setBackground(Color.WHITE);
        dialog.getContentPane().add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);

        postBtn.addActionListener(e -> {
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();
            if (title.isEmpty() || content.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "제목과 내용을 모두 입력해주세요.");
                return;
            }
            Post newPost = new Post(title, content, currentUserNickname);
            currentGame.addPost(newPost);
            dialog.dispose();
            refreshPosts();
        });

        dialog.setVisible(true);
    }

    public void updateLoginState(String nickname) {
        currentUserNickname = nickname;
        Container parent = loginBtn.getParent();
        int idx = parent.getComponentZOrder(loginBtn);
        parent.remove(loginBtn);

        JPanel userBox = new JPanel();
        userBox.setOpaque(false);
        userBox.setLayout(new BoxLayout(userBox, BoxLayout.Y_AXIS));

        JLabel welcome = new JLabel(nickname + "님 환영합니다.");
        welcome.setForeground(Color.WHITE);
        welcome.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton logout = new JButton("로그아웃");
        logout.setAlignmentX(Component.CENTER_ALIGNMENT);
        logout.setMaximumSize(new Dimension(200, 40));
        logout.setBackground(new Color(255, 215, 0));
        logout.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        logout.addActionListener(e -> {
            currentUserNickname = null;
            parent.remove(userBox);
            userMgmtBtn.setVisible(false);
            parent.add(loginBtn, idx);
            parent.revalidate();
            parent.repaint();
        });

        userBox.add(welcome);
        userBox.add(Box.createVerticalStrut(5));
        userBox.add(logout);
        parent.add(userBox, idx);

        if ("admin".equals(nickname)) {
            userMgmtBtn.setVisible(true);
        }

        parent.revalidate();
        parent.repaint();
    }

    private void openNewAskDialogue() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 5);
        g.anchor = GridBagConstraints.WEST;

        JTextField titleField = new JTextField(20);
        JTextArea contentArea = new JTextArea(5, 20);
        JButton postBtn = new JButton("요청 등록");
        postBtn.setBackground(new Color(255, 215, 0));

        g.gridx = 0; g.gridy = 0; panel.add(new JLabel("제목"), g);
        g.gridx = 1; panel.add(titleField, g);
        g.gridx = 0; g.gridy = 1; panel.add(new JLabel("내용"), g);
        g.gridx = 1; panel.add(new JScrollPane(contentArea), g);
        g.gridx = 1; g.gridy = 2; panel.add(postBtn, g);

        JDialog dialog = new JDialog(this, "새 요청 작성", true);
        dialog.getContentPane().setBackground(Color.WHITE);
        dialog.getContentPane().add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);

        postBtn.addActionListener(e -> {
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();
            if (title.isEmpty() || content.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "제목과 내용을 모두 입력해주세요.");
                return;
            }
            long timestamp = System.currentTimeMillis();
            String filename = timestamp + "_" + currentUserNickname + ".txt";
            File outFile = new File(askFolder, filename);
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(outFile))) {
                bw.write(title);
                bw.newLine();
                bw.write("작성자:" + currentUserNickname);
                bw.newLine();
                bw.write(content);
                bw.newLine();
                JOptionPane.showMessageDialog(dialog, "요청이 등록되었습니다.");
                dialog.dispose();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(dialog, "요청 등록 중 오류: " + ex.getMessage());
            }
        });

        dialog.setVisible(true);
    }

    private void showAskListForAdmin() {
        File[] files = askFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
        if (files == null || files.length == 0) {
            JOptionPane.showMessageDialog(this, "등록된 요청이 없습니다.");
            return;
        }

        List<AskEntry> askEntries = new ArrayList<>();
        for (File f : files) {
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String title = br.readLine();
                String authorLine = br.readLine();
                String author = "";
                if (authorLine != null && authorLine.startsWith("작성자:")) {
                    author = authorLine.substring("작성자:".length());
                }
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                String content = sb.toString().trim();
                askEntries.add(new AskEntry(f.getName(), title, author, content));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        JDialog dialog = new JDialog(this, "요청 확인 (admin)", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);

        JPanel listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(Color.WHITE);

        for (AskEntry ae : askEntries) {
            JPanel item = new JPanel(new BorderLayout());
            item.setMaximumSize(new Dimension(460, 60));
            item.setBackground(new Color(230, 230, 230));
            item.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            JButton viewBtn = new JButton(ae.getTitle());
            viewBtn.setHorizontalAlignment(SwingConstants.LEFT);
            viewBtn.setBorderPainted(false);
            viewBtn.setContentAreaFilled(false);
            viewBtn.setForeground(Color.BLACK);
            viewBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
            viewBtn.addActionListener(evt -> {
                JTextArea area = new JTextArea(ae.getContent());
                area.setEditable(false);
                area.setLineWrap(true);
                area.setWrapStyleWord(true);
                area.setBackground(Color.WHITE);
                area.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
                JScrollPane sp = new JScrollPane(area);
                sp.setPreferredSize(new Dimension(400, 300));

                JOptionPane.showMessageDialog(
                        dialog,
                        sp,
                        ae.getTitle() + " - " + ae.getAuthor(),
                        JOptionPane.PLAIN_MESSAGE
                );
            });
            item.add(viewBtn, BorderLayout.CENTER);

            JLabel authorLabel = new JLabel("작성자 : " + ae.getAuthor());
            authorLabel.setForeground(Color.DARK_GRAY);
            authorLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));
            item.add(authorLabel, BorderLayout.EAST);

            listPanel.add(item);
            listPanel.add(Box.createVerticalStrut(5));
        }

        JScrollPane scrollPane = new JScrollPane(listPanel);
        scrollPane.setBorder(null);
        dialog.getContentPane().add(scrollPane);

        dialog.setVisible(true);
    }

    private void showUserManagementDialogue() {
        List<String[]> userLines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(userFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String id = parts[0];
                    String pw = parts[1];
                    String nick = parts[2];
                    if (!"admin".equals(nick)) {
                        userLines.add(new String[]{ id, pw, nick });
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "유저 정보를 불러오는 중 오류: " + e.getMessage());
            return;
        }

        JDialog dialog = new JDialog(this, "유저 관리 (admin)", true);
        dialog.setSize(450, 400);
        dialog.setLocationRelativeTo(this);

        JPanel listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(Color.WHITE);

        for (String[] userData : userLines) {
            String id = userData[0];
            String nick = userData[2];

            JPanel row = new JPanel(new BorderLayout());
            row.setMaximumSize(new Dimension(420, 40));
            row.setBackground(new Color(245, 245, 245));
            row.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            JLabel infoLabel = new JLabel("ID: " + id + "   닉네임: " + nick);
            infoLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
            row.add(infoLabel, BorderLayout.WEST);

            JButton blockBtn = new JButton("차단");
            blockBtn.setForeground(Color.WHITE);
            blockBtn.setBackground(new Color(180, 50, 50));
            blockBtn.setFocusPainted(false);
            blockBtn.setPreferredSize(new Dimension(60, 30));
            blockBtn.addActionListener(e -> {
                List<String> allLines = new ArrayList<>();
                try (BufferedReader br2 = new BufferedReader(new FileReader(userFile))) {
                    String ln;
                    while ((ln = br2.readLine()) != null) {
                        if (!ln.startsWith(id + ",")) {
                            allLines.add(ln);
                        }
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(dialog, "유저 정보 삭제 중 오류: " + ex.getMessage());
                    return;
                }
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(userFile, false))) {
                    for (String s : allLines) {
                        bw.write(s);
                        bw.newLine();
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(dialog, "유저 정보 수정 중 오류: " + ex.getMessage());
                    return;
                }
                listPanel.remove(row);
                listPanel.revalidate();
                listPanel.repaint();
            });

            row.add(blockBtn, BorderLayout.EAST);

            listPanel.add(row);
            listPanel.add(Box.createVerticalStrut(5));
        }

        if (userLines.isEmpty()) {
            JLabel none = new JLabel("차단 가능한 유저가 없습니다.");
            none.setForeground(Color.GRAY);
            none.setFont(new Font("맑은 고딕", Font.ITALIC, 14));
            none.setAlignmentX(Component.CENTER_ALIGNMENT);
            listPanel.add(Box.createVerticalStrut(50));
            listPanel.add(none);
        }

        JScrollPane scrollPane = new JScrollPane(listPanel);
        scrollPane.setBorder(null);
        dialog.getContentPane().add(scrollPane);

        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TFGCommunity().setVisible(true));
    }
}
