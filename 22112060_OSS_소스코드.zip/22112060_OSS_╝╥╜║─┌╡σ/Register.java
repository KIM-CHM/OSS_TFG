import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.HashSet;
import java.util.Set;

public class Register extends JDialog {
    private JTextField idField;
    private JPasswordField pwField;
    private JTextField nickField;
    private JButton joinBtn;
    private JButton backBtn;

    public Register(JFrame parent) {
        super(parent, "회원가입", true);
        setSize(350, 250);
        setResizable(false);
        setLocationRelativeTo(parent);

        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(Color.WHITE);
        backBtn = new JButton("← 뒤로 가기");
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setForeground(Color.GRAY);
        backBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
        backBtn.addActionListener(e -> {
            dispose();
            Login login = new Login((JFrame) getParent());
            login.setVisible(true);
        });
        topPanel.add(backBtn);
        add(topPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel idLabel = new JLabel("ID");
        idField = new JTextField(15);
        JLabel pwLabel = new JLabel("PW");
        pwField = new JPasswordField(15);
        JLabel nickLabel = new JLabel("닉네임");
        nickField = new JTextField(15);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(pwLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(pwField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(nickLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nickField, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        joinBtn = new JButton("가입하기");
        joinBtn.setBackground(new Color(255, 215, 0));
        joinBtn.setOpaque(true);
        joinBtn.setBorderPainted(false);
        joinBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        joinBtn.addActionListener(e -> attemptRegistration());
        bottomPanel.add(joinBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void attemptRegistration() {
        String id = idField.getText().trim();
        String pw = new String(pwField.getPassword()).trim();
        String nick = nickField.getText().trim();

        if (id.isEmpty() || pw.isEmpty() || nick.isEmpty()) {
            JOptionPane.showMessageDialog(this, "모든 항목을 입력해 주세요.");
            return;
        }

        File userFile = new File("data/user.txt");
        Set<String> existingIds = new HashSet<>();
        Set<String> existingNicks = new HashSet<>();

        if (userFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(userFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        existingIds.add(parts[0]);
                        existingNicks.add(parts[2]);
                    }
                }
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "회원 정보를 불러오는 중 오류가 발생했습니다.\n" + ex.getMessage());
                return;
            }
        }

        if (existingIds.contains(id)) {
            JOptionPane.showMessageDialog(this, "이미 존재하는 ID입니다.");
            return;
        }
        if (existingNicks.contains(nick)) {
            JOptionPane.showMessageDialog(this, "이미 존재하는 닉네임입니다.");
            return;
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(userFile, true))) {
            bw.write(id + "," + pw + "," + nick);
            bw.newLine();
            JOptionPane.showMessageDialog(this, "회원가입이 완료되었습니다.");
            dispose();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "회원가입 중 오류가 발생했습니다.\n" + ex.getMessage());
        }
    }

}
