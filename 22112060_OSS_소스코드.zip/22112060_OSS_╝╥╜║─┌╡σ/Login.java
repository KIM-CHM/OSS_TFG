import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Login extends JDialog {
    private JTextField idField;
    private JPasswordField pwField;
    private JButton loginBtn;
    private JButton registerBtn;
    private Map<String, User> users;

    private User loggedInUser = null;

    public Login(JFrame parent) {
        super(parent, "로그인", true);
        users = loadUsers();

        setSize(400, 350);
        setResizable(false);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(250, 250, 251));

        Image logoImg = new ImageIcon("src/img/LogoW.png")
                .getImage()
                .getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(logoImg));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(logoLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel idLabel = new JLabel("ID");
        idField = new JTextField(12);
        JLabel pwLabel = new JLabel("PW");
        pwField = new JPasswordField(12);

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(idField, gbc);
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(pwLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(pwField, gbc);

        loginBtn = new JButton("로그인");
        loginBtn.setBackground(new Color(255, 215, 0));
        loginBtn.setOpaque(true);
        loginBtn.setBorderPainted(false);
        loginBtn.addActionListener(e -> attemptLogin());
        gbc.gridx = 2; gbc.gridy = 0;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.VERTICAL;
        formPanel.add(loginBtn, gbc);

        add(formPanel, BorderLayout.CENTER);

        registerBtn = new JButton("회원가입");
        registerBtn.setForeground(Color.GRAY);
        registerBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
        registerBtn.setFocusPainted(false);
        registerBtn.setContentAreaFilled(false);
        registerBtn.setBorderPainted(false);
        registerBtn.addActionListener(e -> {
            dispose();
            new Register((JFrame) getParent()).setVisible(true);
        });
        add(registerBtn, BorderLayout.SOUTH);
    }

    private void attemptLogin() {
        String id = idField.getText().trim();
        String pw = new String(pwField.getPassword()).trim();

        if (id.isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID와 PW를 모두 입력해주세요.");
            return;
        }
        if (users.containsKey(id)) {
            User u = users.get(id);
            if (u.getPassword().equals(pw)) {
                loggedInUser = u;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "비밀번호가 일치하지 않습니다.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "존재하지 않는 ID입니다.");
        }
    }

    private Map<String, User> loadUsers() {
        Map<String, User> map = new HashMap<>();
        File file = new File("data/user.txt");
        if (!file.exists()) {
            return map;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String id = parts[0];
                    String pw = parts[1];
                    String nick = parts[2];
                    map.put(id, new User(id, pw, nick));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }

    public User showDialogue() {
        setVisible(true);
        return loggedInUser;
    }
}
