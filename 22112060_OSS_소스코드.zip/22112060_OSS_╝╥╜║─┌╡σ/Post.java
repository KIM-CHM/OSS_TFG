public class Post {
    private String title;
    private String content;
    private String author;
    private String filename;

    public Post(String title, String content, String author, String filename) {
        this.title    = title;
        this.content  = content;
        this.author   = author;
        this.filename = filename;
    }

    public Post(String title, String content, String author) {
        this(title, content, author, null);
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
}
