import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Memo extends JFrame {
    private JTextArea textArea;
    private final File memoFile = new File("memo.txt");

    public Memo() {
        setTitle("메모장");
        setSize(400, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        loadMemo();
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton saveBtn = new JButton("저장");
        saveBtn.addActionListener(e -> saveMemo());
        JPanel south = new JPanel();
        south.add(saveBtn);
        add(south, BorderLayout.SOUTH);
    }

    private void loadMemo() {
        if (memoFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(memoFile))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                textArea.setText(sb.toString());
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "메모 불러오기 오류: " + e.getMessage());
            }
        }
    }

    private void saveMemo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(memoFile))) {
            bw.write(textArea.getText());
            JOptionPane.showMessageDialog(this, "저장되었습니다.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "저장 오류: " + e.getMessage());
        }
    }
}
